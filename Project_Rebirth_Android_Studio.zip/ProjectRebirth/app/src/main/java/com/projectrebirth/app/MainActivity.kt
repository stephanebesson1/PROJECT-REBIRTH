package com.projectrebirth.app

import android.Manifest
import android.app.*
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val gold = Color.rgb(224,178,78)
    private val white = Color.WHITE
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13,16,22); window.navigationBarColor = Color.rgb(13,16,22)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
        NotificationPlan.schedule(this)
    }
    private fun buildUi() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,28,24,24); setBackgroundColor(Color.rgb(13,16,22)) }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        addText("PROJECT REBIRTH", 27f, gold, true)
        addText("Reprends le contrôle. Un jour après l'autre.", 14f, 0xFFB8BEC8.toInt(), false)
        addText("TON COMPTEUR", 13f, gold, true)
        val elapsed = (System.currentTimeMillis()-Prefs.start(this)).coerceAtLeast(0)/86400000
        addText("$elapsed JOURS", 38f, white, true)
        val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)
        addText("Départ : ${dateFmt.format(Date(Prefs.start(this)))}", 14f, 0xFFB8BEC8.toInt(), false)
        button("Choisir ma date de départ") {
            val cal = java.util.Calendar.getInstance().apply { timeInMillis=Prefs.start(this@MainActivity) }
            DatePickerDialog(this, { _, y, m, d ->
                val chosen=java.util.Calendar.getInstance().apply { set(y,m,d,0,0,0); set(java.util.Calendar.MILLISECOND,0) }.timeInMillis
                Prefs.setStart(this, chosen); buildUi()
            }, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.DAY_OF_MONTH)).show()
        }
        addText("IDENTITÉ VISUELLE", 13f, gold, true)
        val themes = RadioGroup(this).apply { orientation=RadioGroup.VERTICAL }
        val bat = RadioButton(this).apply { id=android.view.View.generateViewId(); text="Batman — Dark Knight"; setTextColor(white); isChecked=Prefs.theme(this@MainActivity)=="BATMAN" }
        val iron = RadioButton(this).apply { id=android.view.View.generateViewId(); text="Iron Man"; setTextColor(white); isChecked=Prefs.theme(this@MainActivity)=="IRONMAN" }
        themes.addView(bat); themes.addView(iron); themes.setOnCheckedChangeListener { _, id -> Prefs.setTheme(this, if(id==iron.id) "IRONMAN" else "BATMAN") ; refreshWallpaper() }
        root.addView(themes)
        button("Aperçu / appliquer le fond d'écran") {
            try { startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, android.content.ComponentName(this, RebirthWallpaperService::class.java))) }
            catch (_: Exception) { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
        }
        addText("MES INTENTIONS", 13f, gold, true)
        val list = Prefs.intentions(this)
        list.forEachIndexed { i, item ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            val check=CheckBox(this).apply { text=item.text; setTextColor(white); isChecked=item.show; setOnCheckedChangeListener { _, v -> val now=Prefs.intentions(this@MainActivity); if(i<now.size) { now[i]=now[i].copy(show=v); Prefs.saveIntentions(this@MainActivity,now); refreshWallpaper() } } }
            row.addView(check, LinearLayout.LayoutParams(0, -2, 1f))
            val del=TextView(this).apply { text="✕"; textSize=18f; setTextColor(0xFFFF7777.toInt()); setPadding(12,8,12,8); setOnClickListener { val now=Prefs.intentions(this@MainActivity); if(i<now.size) now.removeAt(i); Prefs.saveIntentions(this@MainActivity,now); buildUi() } }
            row.addView(del); root.addView(row)
        }
        val entry=EditText(this).apply { hint="Ajouter une intention…"; setHintTextColor(0xFF9299A5.toInt()); setTextColor(white); setSingleLine(true) }
        root.addView(entry, ViewGroup.LayoutParams(-1,-2))
        button("Ajouter cette intention") { val t=entry.text.toString().trim(); if(t.isNotEmpty()) { val now=Prefs.intentions(this); now.add(Intention(t,true)); Prefs.saveIntentions(this,now); buildUi() } }
        addText("NOTIFICATIONS MOTIVANTES", 13f, gold, true)
        val notif=Switch(this).apply { text="Recevoir une citation chaque jour"; setTextColor(white); isChecked=Prefs.enabled(this@MainActivity); setOnCheckedChangeListener { _, v -> Prefs.setEnabled(this@MainActivity,v); if(v) NotificationPlan.schedule(this@MainActivity) else NotificationPlan.cancel(this@MainActivity) } }
        root.addView(notif)
        addText("Les notifications sont prévues quotidiennement à 9 h. Autorise-les dans les réglages Android.", 12f, 0xFFB8BEC8.toInt(), false)
        addText("Un écart ne remet pas à zéro ta valeur. Si tu choisis de recommencer, tu peux modifier la date. En cas d'envie forte, éloigne-toi des applications de paris et parle à une personne de confiance.", 13f, 0xFFB8BEC8.toInt(), false)
    }
    private fun addText(s:String, size:Float, color:Int, bold:Boolean) {
        root.addView(TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null,1); setPadding(0, if(size>20) 14 else 9, 0, 5) })
    }
    private fun button(s:String, action:()->Unit) {
        root.addView(Button(this).apply { text=s; setOnClickListener { action() } }, ViewGroup.LayoutParams(-1,-2))
    }
    private fun refreshWallpaper() { sendBroadcast(Intent("com.projectrebirth.REFRESH_WALLPAPER")) }
}
