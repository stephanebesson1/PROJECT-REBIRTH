package com.projectrebirth.app

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.graphics.*
import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RebirthWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = RebirthEngine()
    inner class RebirthEngine : Engine() {
        private val handler=Handler(Looper.getMainLooper())
        private var visible=false
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        private val tick=object:Runnable { override fun run() { draw(); if(visible) handler.postDelayed(this,60_000) } }
        override fun onVisibilityChanged(v:Boolean) { visible=v; handler.removeCallbacks(tick); if(v) handler.post(tick) }
        override fun onSurfaceChanged(holder:SurfaceHolder, format:Int, width:Int, height:Int) { super.onSurfaceChanged(holder,format,width,height); draw() }
        override fun onSurfaceDestroyed(holder:SurfaceHolder) { visible=false; handler.removeCallbacks(tick); super.onSurfaceDestroyed(holder) }
        private fun draw() {
            val holder=surfaceHolder
            var canvas:Canvas?=null
            try {
                canvas=holder.lockCanvas() ?: return
                val w=canvas.width.toFloat(); val h=canvas.height.toFloat()
                val iron=Prefs.theme(this@RebirthWallpaperService)=="IRONMAN"
                val bg=if(iron) Color.rgb(27,8,12) else Color.rgb(5,8,14)
                val accent=if(iron) Color.rgb(239,174,56) else Color.rgb(118,174,215)
                canvas.drawColor(bg)
                val glow=Paint(Paint.ANTI_ALIAS_FLAG).apply { shader=RadialGradient(w/2,h*.35f,w*.65f,accent,Color.TRANSPARENT,Shader.TileMode.CLAMP) }
                canvas.drawRect(0f,0f,w,h,glow)
                paint.shader=null; paint.color=accent; paint.textAlign=Paint.Align.CENTER; paint.typeface=Typeface.create("sans-serif-condensed",Typeface.BOLD)
                paint.textSize=w*.065f; canvas.drawText(if(iron) "PROJECT REBIRTH • IRON MAN" else "PROJECT REBIRTH • DARK KNIGHT",w/2,h*.16f,paint)
                val days=((System.currentTimeMillis()-Prefs.start(this@RebirthWallpaperService)).coerceAtLeast(0)/86400000)
                paint.color=Color.WHITE; paint.textSize=w*.17f; canvas.drawText("$days",w/2,h*.36f,paint)
                paint.textSize=w*.045f; paint.color=accent; canvas.drawText(if(days==1L) "JOUR SANS PARI" else "JOURS SANS PARI",w/2,h*.415f,paint)
                paint.color=0xFFE3E7ED.toInt(); paint.textSize=w*.043f; paint.typeface=Typeface.create("sans-serif",Typeface.NORMAL)
                val date=SimpleDateFormat("dd MMM yyyy",Locale.FRANCE).format(Date(Prefs.start(this@RebirthWallpaperService)))
                canvas.drawText("Depuis le $date",w/2,h*.47f,paint)
                val intentions=Prefs.intentions(this@RebirthWallpaperService).filter { it.show }.take(3)
                var y=h*.61f
                intentions.forEach { item ->
                    paint.color=accent; paint.textSize=w*.038f
                    val text=if(item.text.length>38) item.text.take(35)+"…" else item.text
                    canvas.drawText("• $text",w/2,y,paint); y+=h*.055f
                }
                paint.color=Color.WHITE; paint.textSize=w*.038f
                canvas.drawText("Un jour après l'autre.",w/2,h*.91f,paint)
            } catch (_:Exception) { } finally { if(canvas!=null) holder.unlockCanvasAndPost(canvas) }
        }
    }
}
