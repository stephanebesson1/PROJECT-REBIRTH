package com.projectrebirth.app

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

object NotificationPlan {
    fun schedule(c:Context) {
        val alarm=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi=PendingIntent.getBroadcast(c,77,Intent(c,QuoteReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal=Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,9); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); if(timeInMillis<=System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1) }
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
    }
    fun cancel(c:Context) {
        val pi=PendingIntent.getBroadcast(c,77,Intent(c,QuoteReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
    }
}
class QuoteReceiver:BroadcastReceiver() {
    override fun onReceive(c:Context, i:Intent?) {
        if(!Prefs.enabled(c)) return
        if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val quotes=listOf(
            "Chaque euro que tu ne mises pas est un euro que tu récupères.",
            "Tu n'as pas besoin de te refaire. Tu peux choisir de ne plus jouer.",
            "Une envie passe. La liberté que tu construis reste.",
            "Le vrai pari gagnant, c'est de miser sur toi-même.",
            "Aujourd'hui, protège ta paix plutôt que de poursuivre un résultat.",
            "La progression n'est pas toujours linéaire. Reviens à ton objectif, sans te juger.",
            "Tu reprends du temps, de l'argent et de l'espace mental. Continue."
        )
        val manager=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel("rebirth_quotes","Citations Project Rebirth",NotificationManager.IMPORTANCE_DEFAULT))
        val quote=quotes[(System.currentTimeMillis()/86400000 % quotes.size).toInt()]
        val n=NotificationCompat.Builder(c,"rebirth_quotes").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Project Rebirth").setContentText(quote).setStyle(NotificationCompat.BigTextStyle().bigText(quote)).setAutoCancel(true).build()
        manager.notify(77,n)
    }
}
class BootReceiver:BroadcastReceiver() {
    override fun onReceive(c:Context,i:Intent?) { if(Prefs.enabled(c)) NotificationPlan.schedule(c) }
}
