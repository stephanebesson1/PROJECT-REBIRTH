package com.projectrebirth.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Intention(val text: String, val show: Boolean)

object Prefs {
    private const val FILE = "rebirth"
    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun start(c: Context): Long = p(c).getLong("start", System.currentTimeMillis())
    fun setStart(c: Context, value: Long) { p(c).edit().putLong("start", value).apply() }
    fun theme(c: Context): String = p(c).getString("theme", "BATMAN") ?: "BATMAN"
    fun setTheme(c: Context, value: String) { p(c).edit().putString("theme", value).apply() }
    fun enabled(c: Context): Boolean = p(c).getBoolean("notifications", true)
    fun setEnabled(c: Context, value: Boolean) { p(c).edit().putBoolean("notifications", value).apply() }
    fun intentions(c: Context): MutableList<Intention> {
        val raw = p(c).getString("intentions", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return MutableList(arr.length()) { i ->
            val o = arr.getJSONObject(i); Intention(o.optString("text"), o.optBoolean("show", true))
        }
    }
    fun saveIntentions(c: Context, items: List<Intention>) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("text", it.text).put("show", it.show)) }
        p(c).edit().putString("intentions", arr.toString()).apply()
    }
}
