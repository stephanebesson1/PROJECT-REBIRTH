# Project Rebirth — Android

Projet Android Studio (Kotlin) de départ : compteur d'abstinence, intentions, notifications quotidiennes et fond d'écran animé Android.

## Ouvrir et compiler
1. Installe Android Studio (version récente) et le JDK 17.
2. Décompresse le dossier et ouvre `ProjectRebirth` dans Android Studio.
3. Laisse Gradle synchroniser le projet (SDK Android 35 requis).
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK debug se trouve normalement dans `app/build/outputs/apk/debug/app-debug.apk`.

## Installer le fond d'écran
Dans l'application, choisis le thème et touche « Aperçu / appliquer le fond d'écran », puis applique-le depuis l'écran système.

## Fonctions incluses
- Date de départ modifiable.
- Calcul du nombre de jours.
- Thèmes Batman sombre et Iron Man rouge/or.
- Intentions ajoutables, supprimables et individuellement affichables sur le fond.
- Notification quotidienne de citation à 9 h, désactivable.
- Reprogrammation après redémarrage.

## Limites Android à connaître
Android permet de définir un fond d'écran animé, mais son affichage sur l'écran de verrouillage dépend du fabricant et de la version Android. Certains appareils ne proposent le fond animé que sur l'écran d'accueil. Le projet ne peut pas forcer ce comportement.
Les notifications nécessitent l'autorisation Android 13+.

## Personnalisation / prochaine étape
Le projet constitue une première version fonctionnelle à compiler et tester. Il n'intègre pas encore de synchronisation cloud, de statistiques avancées, ni de mécanisme de sauvegarde/export des données. Les données restent locales sur le téléphone.
